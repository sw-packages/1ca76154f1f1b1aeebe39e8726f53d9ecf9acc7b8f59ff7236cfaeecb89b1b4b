// Copyright (c) Darrell Wright
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// Official repository: https://github.com/beached/header_libraries
//

#pragma once

#include "daw_cpp_feature_check.h"

#include <cassert>

#ifndef NDEBUG

#define DAW_ASSUME( ... ) assert( (__VA_ARGS__) )

#else

#if DAW_HAS_BUILTIN( __builtin_unreachable )

#define DAW_ASSUME( ... )                                                      \
	do {                                                                         \
		while( not( ( __VA_ARGS__ ) ) ) {                                          \
			__builtin_unreachable( );                                                \
		}                                                                          \
	} while( false )

#elif defined( _MSC_VER )

#define DAW_ASSUME( ... ) __assume( !!( ( __VA_ARGS__ ) ) )

#else

#define DAW_ASSUME( ... )                                                      \
	do {                                                                         \
	} while( false )
#endif
#endif
